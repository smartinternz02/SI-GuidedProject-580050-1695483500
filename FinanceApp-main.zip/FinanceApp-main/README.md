The main files of the app are MainActivity.kt and the drawables file which contain the image resources for the app.
Just copy over those files into an empty project and you are good to go.
